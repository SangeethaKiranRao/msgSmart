require File.join(File.dirname(__FILE__), "rails", "init")
