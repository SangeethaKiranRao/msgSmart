require File.join(File.dirname(__FILE__), "..", "lib", "authentication")
require File.join(File.dirname(__FILE__), "..", "lib", "authentication", "by_password")
require File.join(File.dirname(__FILE__), "..", "lib", "authentication", "by_cookie_token")
