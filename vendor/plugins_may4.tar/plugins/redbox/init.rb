
require 'redbox_helper'

ActionView::Base.send(:include, RedboxHelper)
