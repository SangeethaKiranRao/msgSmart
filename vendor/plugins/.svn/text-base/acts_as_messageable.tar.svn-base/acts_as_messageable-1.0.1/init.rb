# Include hook code here
require 'acts_as_messageable'