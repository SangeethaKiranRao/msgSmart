puts IO.read(File.join(File.dirname(__FILE__), 'README'))
